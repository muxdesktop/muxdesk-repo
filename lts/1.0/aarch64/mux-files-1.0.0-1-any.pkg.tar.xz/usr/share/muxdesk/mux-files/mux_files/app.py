"""Mux Files — Application entry. কেন Python/GTK4: নিচে README-তে যুক্তি।"""
from __future__ import annotations

import os
import sys

from gi.repository import Gio, Gtk

from . import APP_ID
from .window import MuxFilesWindow

CSS_CANDIDATES = (
    os.path.join(os.path.dirname(__file__), "data", "mux-files.css"),
    "/usr/share/muxdesk/mux-files/mux-files.css",
    os.path.expanduser("~/.local/share/muxdesk/mux-files/mux-files.css"),
)


def _load_css():
    for path in CSS_CANDIDATES:
        if os.path.isfile(path):
            provider = Gtk.CssProvider()
            provider.load_from_path(path)
            from gi.repository import Gdk
            Gtk.StyleContext.add_provider_for_display(
                Gdk.Display.get_default(), provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
            return


class MuxFilesApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gio.ApplicationFlags.HANDLES_OPEN)

    def do_startup(self):
        Gtk.Application.do_startup(self)
        # traffic-light বান্ধব: window বোতাম বামে (close, minimize, maximize)
        settings = Gtk.Settings.get_default()
        if settings is not None:
            settings.set_property("gtk-decoration-layout", "close,minimize,maximize:")
        _load_css()

    def do_activate(self):
        win = self.props.active_window or MuxFilesWindow(self)
        win.present()

    def do_open(self, files, _n, _hint):
        win = self.props.active_window or MuxFilesWindow(self)
        if files and files[0].query_file_type(0, None) == Gio.FileType.DIRECTORY:
            win.navigate(files[0], record=False)
        win.present()


def main(argv: list[str] | None = None) -> int:
    return MuxFilesApp().run(argv if argv is not None else sys.argv)
