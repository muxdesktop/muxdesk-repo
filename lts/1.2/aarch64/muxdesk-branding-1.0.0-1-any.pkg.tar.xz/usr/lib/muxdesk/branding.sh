#!/bin/bash
# MuxDesk branding — distro-র ভিতরে চলে।
# কাজ: সব জায়গায় Arch/proot নাম সরিয়ে MuxDesk নাম + আমাদের logo বসানো।
#   /etc/os-release, hostname, issue, motd, fastfetch/neofetch config, muxinfo
# ব্যবহার: bash branding.sh arch — MuxDesk-এর base শুধুই Arch, অন্য কোনো base নেই।
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
[ -f "$SRC/logo.txt" ] || SRC=/usr/share/muxdesk

# MuxDesk শুধুই Arch-ভিত্তিক — base সবসময় arch
BASE=arch
ID_LIKE=arch

mkdir -p /usr/share/muxdesk
cp "$SRC/logo.txt" /usr/share/muxdesk/logo.txt 2>/dev/null || true
cp "$SRC/logo.svg" /usr/share/muxdesk/logo.svg 2>/dev/null || true
mkdir -p /usr/share/icons/hicolor/scalable/apps /usr/share/pixmaps
cp /usr/share/muxdesk/logo.svg /usr/share/icons/hicolor/scalable/apps/muxdesk.svg 2>/dev/null || true
cp /usr/share/muxdesk/logo.svg /usr/share/pixmaps/muxdesk.svg 2>/dev/null || true
# PNG size গুলো (16–512): যেই tool scalable SVG পড়ে না, তার জন্য। রূপান্তরের
# tool (rsvg-convert / ImageMagick / inkscape) থাকলে বানানো হয় — নিচে
# fastfetch-এর সাথে librsvg বসানোর পর আবার চেষ্টা করা হয় (make_pngs)।

# --- 1) OS identity: MuxDesk আসল derivative distro — নিজের ID, rename নয় ---
# Ubuntu যেমন Debian থেকে নিজের ID নিয়ে আলাদা distro, MuxDesk-ও Arch থেকে
# নিজের ID (muxdesk) + ID_LIKE=arch নিয়ে আলাদা। GNOME Settings > About আর
# COSMIC Settings os-release-এর NAME/PRETTY_NAME আর LOGO field থেকেই
# নাম+logo নেয় — তাই LOGO=muxdesk আর উপরের icon জায়গাগুলোই আসল কৌশল।
cat > /etc/os-release <<EOF
PRETTY_NAME="MuxDesk 1.0"
NAME="MuxDesk"
VERSION_ID="1.0"
VERSION="1.0 (Desk)"
VERSION_CODENAME=desk
ID=muxdesk
ID_LIKE=$ID_LIKE
HOME_URL="https://muxdesk.local"
SUPPORT_URL="https://muxdesk.local/support"
BUG_REPORT_URL="https://muxdesk.local/issues"
LOGO=muxdesk
EOF
cp /etc/os-release /usr/lib/os-release 2>/dev/null || true
cat > /etc/lsb-release <<'EOF'
DISTRIB_ID=MuxDesk
DISTRIB_RELEASE=1.0
DISTRIB_CODENAME=desk
DISTRIB_DESCRIPTION="MuxDesk 1.0"
EOF
cp /etc/lsb-release /usr/lib/lsb-release 2>/dev/null || true
# lsb_release -a তেও যেন MuxDesk-ই আসে: আসল lsb-release package বসানোর
# চেষ্টা হয় (নিচে pacman ধাপে); না মিললে /etc/lsb-release পড়ে এমন
# হালকা shim বসে — দুটোতেই উৎস একই file, তাই ফল একই হবে।

# --- 2) Hostname / login banner ---
echo "muxdesk" > /etc/hostname
grep -q ' muxdesk' /etc/hosts 2>/dev/null || echo "127.0.1.1 muxdesk" >> /etc/hosts
{ cat /usr/share/muxdesk/logo.txt; echo "MuxDesk 1.0 \\n \\l"; } > /etc/issue
{ echo ""; cat /usr/share/muxdesk/logo.txt; echo "  Welcome to MuxDesk 1.0 — info dekhte: muxinfo"; echo ""; } > /etc/motd

# --- 3) fastfetch / neofetch-এ আমাদের logo ---
pacman -S --noconfirm --needed fastfetch librsvg lsb-release 2>/dev/null || \
pacman -S --noconfirm --needed fastfetch 2>/dev/null || true
# PNG logo size গুলো বানাও (tool যেটা পাওয়া যায় সেটা দিয়ে; না পেলে SVG-ই থাকলো)
for _s in 16 22 24 32 48 64 128 256 512; do
  _d="/usr/share/icons/hicolor/${_s}x${_s}/apps"; mkdir -p "$_d"
  [ -f "$_d/muxdesk.png" ] && continue
  if command -v rsvg-convert >/dev/null 2>&1; then
    rsvg-convert -w "$_s" -h "$_s" /usr/share/muxdesk/logo.svg -o "$_d/muxdesk.png" 2>/dev/null || true
  elif command -v magick >/dev/null 2>&1; then
    magick -background none -resize "${_s}x${_s}" /usr/share/muxdesk/logo.svg "$_d/muxdesk.png" 2>/dev/null || true
  elif command -v convert >/dev/null 2>&1; then
    convert -background none -resize "${_s}x${_s}" /usr/share/muxdesk/logo.svg "$_d/muxdesk.png" 2>/dev/null || true
  elif command -v inkscape >/dev/null 2>&1; then
    inkscape -w "$_s" -h "$_s" /usr/share/muxdesk/logo.svg -o "$_d/muxdesk.png" 2>/dev/null || true
  fi
done
cp /usr/share/icons/hicolor/512x512/apps/muxdesk.png /usr/share/pixmaps/muxdesk.png 2>/dev/null || true
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -f /usr/share/icons/hicolor 2>/dev/null || true
# lsb_release না থাকলে shim (ওপরে বলা হয়েছে) — -a/--all আর -d দুটোই ধরে
if ! command -v lsb_release >/dev/null 2>&1; then
  cat > /usr/local/bin/lsb_release <<'EOS'
#!/bin/bash
# MuxDesk shim: /etc/lsb-release থেকে পড়ে (আসল package না থাকলে)
DISTRIB_ID=MuxDesk; DISTRIB_RELEASE=1.0; DISTRIB_CODENAME=desk; DISTRIB_DESCRIPTION="MuxDesk 1.0"
[ -f /etc/lsb-release ] && . /etc/lsb-release
case "${1:-}" in
  -d|--description) echo "Description:\t$DISTRIB_DESCRIPTION" ;;
  -i|--id) echo "Distributor ID:\t$DISTRIB_ID" ;;
  -r|--release) echo "Release:\t$DISTRIB_RELEASE" ;;
  -c|--codename) echo "Codename:\t$DISTRIB_CODENAME" ;;
  *) echo "LSB Version:\tn/a"; echo "Distributor ID:\t$DISTRIB_ID"; echo "Description:\t$DISTRIB_DESCRIPTION"; echo "Release:\t$DISTRIB_RELEASE"; echo "Codename:\t$DISTRIB_CODENAME" ;;
esac
EOS
  chmod +x /usr/local/bin/lsb_release
fi

write_fetch_config() {  # $1 = home dir
  local home="$1"
  mkdir -p "$home/.config/fastfetch" "$home/.config/neofetch"
  cat > "$home/.config/fastfetch/config.jsonc" <<'EOF'
{
  "$schema": "https://github.com/fastfetch-cli/fastfetch/raw/dev/doc/json_schema.json",
  "logo": { "source": "/usr/share/muxdesk/logo.txt", "type": "file-raw",
            "color": { "1": "38;2;124;92;255", "2": "38;2;0;194;168" },
            "padding": { "right": 3, "top": 1 } },
  "modules": ["title","separator","os","host","kernel","uptime","packages",
              "shell","de","wm","terminal","cpu","memory","disk","break","colors"]
}
EOF
  cat > "$home/.config/neofetch/config.conf" <<'EOF'
image_backend="ascii"
image_source="/usr/share/muxdesk/logo.txt"
ascii_distro="MuxDesk"
EOF
}
write_fetch_config /root
write_fetch_config /etc/skel
[ -d /home/desk ] && write_fetch_config /home/desk && chown -R desk:desk /home/desk/.config || true

# --- 4) muxinfo command — এটা দিলেই logo + MuxDesk name show করবে ---
cat > /usr/local/bin/muxinfo <<'EOS'
#!/bin/bash
C1='\033[38;2;124;92;255m'; C2='\033[38;2;0;194;168m'; B='\033[1m'; R='\033[0m'
OS=$(grep '^PRETTY_NAME=' /etc/os-release | cut -d'"' -f2)
DE="${XDG_CURRENT_DESKTOP:-${DESKTOP_SESSION:-unknown}}"
[ "$DE" = unknown ] && { pgrep -x gnome-shell >/dev/null && DE=GNOME; pgrep -x cosmic-comp >/dev/null && DE=COSMIC; }
PKGS="$(pacman -Qq 2>/dev/null | wc -l) (pacman)"
mapfile -t LOGO < /usr/share/muxdesk/logo.txt
INFO=(
  "${B}$(whoami)@$(hostname)${R}"
  "─────────────────────"
  "${B}OS:${R}       $OS ($(uname -m))"
  "${B}Host:${R}     MuxDesk on Termux (non-root)"
  "${B}Kernel:${R}   $(uname -sr)"
  "${B}Uptime:${R}   $(uptime -p 2>/dev/null | sed 's/^up //')"
  "${B}Packages:${R} $PKGS"
  "${B}Shell:${R}    $SHELL"
  "${B}DE:${R}        $DE"
  "${B}CPU:${R}      $(grep -m1 'model name\|Hardware' /proc/cpuinfo | cut -d: -f2 | sed 's/^ //')"
  "${B}Memory:${R}   $(free -h | awk '/^Mem:/{print $3" / "$2}')"
)
for i in "${!INFO[@]}"; do
  printf "${C1}%-22s${R} %b\n" "${LOGO[$i]:-}" "${INFO[$i]}"
done
for ((i=${#INFO[@]}; i<${#LOGO[@]}; i++)); do printf "${C2}%s${R}\n" "${LOGO[$i]}"; done
EOS
chmod +x /usr/local/bin/muxinfo
# neofetch নামে ডাকলেও আমাদেরটাই আসুক, যদি আসল neofetch না থাকে
command -v neofetch >/dev/null || ln -sf muxinfo /usr/local/bin/neofetch
echo "Branding done: name=MuxDesk (base: $BASE), command: muxinfo / fastfetch"
