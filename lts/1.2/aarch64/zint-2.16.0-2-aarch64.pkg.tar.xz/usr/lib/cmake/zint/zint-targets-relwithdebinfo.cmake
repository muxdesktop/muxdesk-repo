#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "zint::zint" for configuration "RelWithDebInfo"
set_property(TARGET zint::zint APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(zint::zint PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libzint.so.2.16.0.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libzint.so.2.16"
  )

list(APPEND _cmake_import_check_targets zint::zint )
list(APPEND _cmake_import_check_files_for_zint::zint "${_IMPORT_PREFIX}/lib/libzint.so.2.16.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
