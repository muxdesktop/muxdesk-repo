# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) Contributors to the OpenEXR Project.


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was OpenEXRConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/OpenEXR" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

set(openexr_needthreads ON)
if (openexr_needthreads)
  set(THREADS_PREFER_PTHREAD_FLAG ON)
  find_dependency(Threads)
endif()
unset(openexr_needthreads)

find_dependency(Imath)

# A static OpenEXRCore links to any dependency found via pkg-config through
# a PkgConfig:: imported target, which must be recreated here.
macro(openexr_find_pkgconfig_dependency prefix module)
  if (NOT TARGET PkgConfig::${prefix})
    find_dependency(PkgConfig)
    pkg_check_modules(${prefix} REQUIRED QUIET IMPORTED_TARGET GLOBAL ${module})
  endif()
endmacro()

if ("libdeflate::libdeflate_shared" STREQUAL "PkgConfig::deflate")
  if (NOT ON)
    openexr_find_pkgconfig_dependency(deflate libdeflate)
  endif()
elseif (1)
  find_dependency(libdeflate)
endif()

if ("openjph" STREQUAL "PkgConfig::openjph")
  if (NOT ON)
    openexr_find_pkgconfig_dependency(openjph "openjph=0.33.0")
  endif()
elseif (NOT 0)
  # Workaround for OpenJPH 0.33.0: its exported CMake target links to
  # Threads::Threads, but its package config does not find_dependency(Threads),
  # so the find_dependency(openjph) below fails in a consuming project that has
  # not already found Threads. That includes an OpenEXR built with
  # OPENEXR_ENABLE_THREADING=OFF (the block above did not look for Threads) and
  # any downstream project that does not use threads itself. Define it here.
  #
  # This mirrors the equivalent build-time workaround in OpenEXRSetup.cmake.
  # Remove once OpenEXR's minimum OpenJPH is a release that includes the
  # upstream fix, https://github.com/aous72/OpenJPH/pull/420. Note that the
  # OpenEXR 3.5 release cannot raise that minimum, so this must stay for as
  # long as 3.5 is supported.
  if (NOT TARGET Threads::Threads)
    set(THREADS_PREFER_PTHREAD_FLAG ON)
    find_dependency(Threads)
  endif()
  find_dependency(openjph)
endif()

if ("zstd::libzstd_shared" STREQUAL "PkgConfig::libzstd")
  if (NOT ON)
    openexr_find_pkgconfig_dependency(libzstd libzstd)
  endif()
elseif (1)
  find_dependency(zstd CONFIG)
endif()

include("${CMAKE_CURRENT_LIST_DIR}/OpenEXRTargets.cmake")
check_required_components("OpenEXR")
