/*
 * Copyright (C) 2023 James Westman <james@jwestman.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, see <https://www.gnu.org/licenses/>.
 */

#pragma once

#include <glib-object.h>
#include <shumate/shumate-vector-reader-iter.h>
#include <shumate/shumate-version.h>

G_BEGIN_DECLS

SHUMATE_AVAILABLE_MACRO_IN_1_2
#define SHUMATE_TYPE_VECTOR_READER (shumate_vector_reader_get_type ())
G_DECLARE_FINAL_TYPE (ShumateVectorReader, shumate_vector_reader, SHUMATE, VECTOR_READER, GObject)

SHUMATE_AVAILABLE_IN_1_2
ShumateVectorReader *shumate_vector_reader_new (GBytes *bytes);
SHUMATE_AVAILABLE_IN_1_2
ShumateVectorReaderIter *shumate_vector_reader_iterate (ShumateVectorReader *self);

SHUMATE_AVAILABLE_IN_1_2
ShumateVectorReader *shumate_vector_reader_iter_get_reader (ShumateVectorReaderIter *self);

G_END_DECLS
