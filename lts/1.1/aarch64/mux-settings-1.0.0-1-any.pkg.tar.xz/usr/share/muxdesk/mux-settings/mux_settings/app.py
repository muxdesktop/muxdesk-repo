"""Mux Settings — Application entry।"""
from __future__ import annotations

import os
import sys

from gi.repository import Gdk, Gio, Gtk

from . import APP_ID
from .window import MuxSettingsWindow

CSS_CANDIDATES = (
    os.path.join(os.path.dirname(__file__), "data", "mux-settings.css"),
    "/usr/share/muxdesk/mux-settings/mux-settings.css",
    os.path.expanduser("~/.local/share/muxdesk/mux-settings/mux-settings.css"),
)


class MuxSettingsApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_startup(self):
        Gtk.Application.do_startup(self)
        settings = Gtk.Settings.get_default()
        if settings is not None:  # traffic-light বান্ধব: বোতাম বামে
            settings.set_property("gtk-decoration-layout", "close,minimize,maximize:")
        for path in CSS_CANDIDATES:
            if os.path.isfile(path):
                provider = Gtk.CssProvider()
                provider.load_from_path(path)
                Gtk.StyleContext.add_provider_for_display(
                    Gdk.Display.get_default(), provider,
                    Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
                break

    def do_activate(self):
        win = self.props.active_window or MuxSettingsWindow(self)
        win.present()


def main(argv: list[str] | None = None) -> int:
    return MuxSettingsApp().run(argv if argv is not None else sys.argv)
