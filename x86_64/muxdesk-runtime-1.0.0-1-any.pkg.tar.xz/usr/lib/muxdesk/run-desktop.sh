#!/bin/bash
# কোন session install হয়েছে + display কোনটা, দেখে সেভাবেই চালায়।
# Display matrix (v3.2):
#   GNOME  -> Wayland ONLY। সর্বশেষ GNOME (50+)-এ X11 session নেই — তাই
#             gnome-shell সরাসরি MuxDesktop app-এর built-in Wayland
#             server-এ চলে, XDG_SESSION_TYPE=wayland। (--nested flag টা শুধু
#             DRM ছাড়া host Wayland socket-এ বসার command-line flag — আলাদা
#             কোনো nested test mode বা আরেক desktop-এর ভিতরে desktop নয়।)
#             X11 app ভিতরে XWayland দিয়ে চলবে।
#   COSMIC -> Wayland ONLY (নিজেই Wayland compositor) — একই host server-এ।
#   XFCE   -> X11 (startxfce4) বা Wayland (startxfce4 --wayland, labwc থাকলে)।
# Rootless ফোনে DRM/KMS বা logind নেই — তাই desktop hardware compositor
# হিসেবে না চলে app-এর built-in Wayland server-কেই সরাসরি ব্যবহার করে।
S="$(cat /etc/muxdesk-session 2>/dev/null || echo 'session: gnome')"
D="$(cat /etc/muxdesk-display 2>/dev/null || echo x11)"
export LIBGL_ALWAYS_SOFTWARE=1 GSK_RENDERER=cairo

run_dbus() {  # dbus-run-session থাকলে সেটা, না হলে dbus-launch
  if command -v dbus-run-session >/dev/null 2>&1; then
    dbus-run-session -- "$@"
  else
    dbus-launch --exit-with-session "$@"
  fi
}

case "$S" in
  *cosmic*)
    export WAYLAND_DISPLAY="${WAYLAND_DISPLAY:-wayland-0}" XDG_SESSION_TYPE=wayland
    run_dbus cosmic-session
    rc=$?
    if [ $rc -ne 0 ]; then
      echo ""
      echo "সতর্কতা: cosmic-session চালু হতে পারেনি (exit code $rc)।"
      echo "সম্ভাব্য কারণ: stock Arch build-এর cosmic-comp এই host Wayland socket-এ"
      echo "চালু হতে পারছে না। Rootless ফোনে DRM/KMS নেই — MuxDesktop app-এর নিজের"
      echo "built-in Wayland server-ই শেষ পর্যন্ত COSMIC-এর সরাসরি Wayland পথ দেবে।"
      echo "ততদিন GNOME বা XFCE চালাও (install.sh দিয়ে desktop বদলে আবার install করো)।"
    fi
    ;;
  *xfce*)
    if [ "$D" = wayland ]; then
      if command -v labwc >/dev/null 2>&1; then
        export XDG_SESSION_TYPE=wayland
        exec run_dbus startxfce4 --wayland
      else
        echo "সতর্কতা: XFCE-এর Wayland session-এর অংশ (labwc) পাওয়া যায়নি —"
        echo "এই repo-র Xfce-তে Wayland session নেই/অসম্পূর্ণ। X11 দিয়ে চালানো হচ্ছে।"
        exec dbus-launch --exit-with-session startxfce4
      fi
    else
      exec dbus-launch --exit-with-session startxfce4
    fi
    ;;
  *)
    # GNOME — Wayland only, সরাসরি built-in Wayland server-এ
    export WAYLAND_DISPLAY="${WAYLAND_DISPLAY:-wayland-0}" XDG_SESSION_TYPE=wayland
    exec run_dbus gnome-shell --nested --wayland
    ;;
esac
